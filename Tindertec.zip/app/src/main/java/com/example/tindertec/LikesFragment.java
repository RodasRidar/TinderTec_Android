package com.example.tindertec;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.tindertec.adapter.PictureAdapterRecyclerView;
import com.example.tindertec.models.Usuario;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.tindertec.adapter.PictureAdapterRecyclerView;
import java.util.ArrayList;
import java.util.List;


public class LikesFragment extends Fragment  {

    private RecyclerView recyclerView;
    private PictureAdapterRecyclerView adapter;
    private List<Usuario> item;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Intent a = new Intent(getActivity(), MeGustasActivity.class);
        //startActivity(a);
       // initValues();
        //initViews();
    }
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        getItems();

        recyclerView = (RecyclerView) getActivity().findViewById(R.id.recycleViewLists);

        adapter = new PictureAdapterRecyclerView(item);

        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getActivity());

        recyclerView.setLayoutManager(layoutManager);

        recyclerView.setAdapter(adapter);

        return inflater.inflate(R.layout.fragment_likes ,container,false);
    }
    private void initViews(){

        recyclerView = recyclerView.findViewById(R.id.recycleViewLists);
    }

    private void initValues(){
        LinearLayoutManager manager = new LinearLayoutManager(getActivity());
        recyclerView.setLayoutManager(manager);
        item=getItems();
        adapter=new PictureAdapterRecyclerView(item);
        recyclerView.setAdapter(adapter);
    }

    private List<Usuario> getItems(){
        List<Usuario> Usuarios=new ArrayList<>();
        Usuarios.add(new Usuario("Gabriela Goyburo","https://images.pexels.com/photos/2119370/pexels-photo-2119370.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1","Computacion e Informatica"));
        Usuarios.add(new Usuario("Daniela Barraza","https://images.pexels.com/photos/2739750/pexels-photo-2739750.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1","Publicidad"));

        return Usuarios;
    }
}