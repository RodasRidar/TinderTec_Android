package com.example.tindertec;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;

import com.example.tindertec.adapter.PictureAdapterRecyclerView;
import com.example.tindertec.models.Usuario;

import java.util.ArrayList;
import java.util.List;

public class MeGustasActivity extends AppCompatActivity {
    private RecyclerView recyclerView;
    private PictureAdapterRecyclerView adapter;
    private List<Usuario> item;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_me_gustas);
       // Toolbar toolbar = findViewById(R.id.toolbar);
       // setSupportActionBar(toolbar);
        initViews();
        initValues();

    }
    private void initViews(){

        recyclerView = findViewById(R.id.recycleViewList);
    }

    private void initValues(){
        LinearLayoutManager manager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(manager);
        item=getItems();
        adapter=new PictureAdapterRecyclerView(item);
        recyclerView.setAdapter(adapter);
    }
    private  List<Usuario> getItems(){
        List<Usuario> Usuarios=new ArrayList<>();


/*
        cursor.moveToLast();
        int i=cursor.getCount();
        String nom;
        String det;
        String url;
        while ( i>0)
        {
            nom=cursor.getString(0);
            det=cursor.getString(1);
            url=cursor.getString(2);
            Usuarios.add(new Usuario(nom,det,url));
            cursor.moveToPrevious();
            i--;

        }
        cursor.close();*/

        Usuarios.add(new Usuario("Gabriela Goyburo","https://images.pexels.com/photos/2119370/pexels-photo-2119370.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1","Computacion e Informatica"));
        Usuarios.add(new Usuario("Daniela Barraza","https://images.pexels.com/photos/2739750/pexels-photo-2739750.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1","Publicidad"));

        return Usuarios;
    }
}